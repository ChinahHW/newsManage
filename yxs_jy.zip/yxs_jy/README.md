# yxs_jy

#### 介绍
益小书教育

#### 软件架构
软件架构说明
1. 首页     index.html
2. 静态资源文件     static
3. 模块页面     pages


#### 页面路径
1. 首页          /yxs_jy/index.html
2. 成人高考       /yxs_jy/pages/adult_exam/index.html
3. 自学考试       /yxs_jy/pages/examination/index.html
4. 执业药师       /yxs_jy/pages/licensed_pharmacist/index.html
5. 网络教育       /yxs_jy/pages/webucation/index.html
6. 招生专业       /yxs_jy/pages/professional_admissions/index.html
7. 导航栏详情     /yxs_jy/pages/whole_navbar/index.html
8. 常见问题       /yxs_jy/pages/usual_question/index.html
9. 院校招生详情   /yxs_jy/pages/school_detail/index.html
10. 招生简章      /yxs_jy/pages/admissions_article/index.html
11. 注册          /yxs_jy/pages/register.html
12. 登录          /yxs_jy/pages/login.html
13. 个人中心      /yxs_jy/pages/personal.html


#### 安装教程

1. xxxx
2. xxxx
3. xxxx

#### 使用说明

1. xxxx
2. xxxx
3. xxxx

#### 参与贡献

1. Fork 本仓库
2. 新建 Feat_xxx 分支
3. 提交代码
4. 新建 Pull Request


#### 码云特技

1. 使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2. 码云官方博客 [blog.gitee.com](https://blog.gitee.com)
3. 你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解码云上的优秀开源项目
4. [GVP](https://gitee.com/gvp) 全称是码云最有价值开源项目，是码云综合评定出的优秀开源项目
5. 码云官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6. 码云封面人物是一档用来展示码云会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)